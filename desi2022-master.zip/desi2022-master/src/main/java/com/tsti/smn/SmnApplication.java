package com.tsti.smn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmnApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(SmnApplication.class, args); //inicia la aplicación
		
	}

}
