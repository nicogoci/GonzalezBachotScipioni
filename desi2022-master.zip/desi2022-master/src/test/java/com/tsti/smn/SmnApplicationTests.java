package com.tsti.smn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmnApplicationTests {

	@Test
	void contextLoads() {
	}

}
